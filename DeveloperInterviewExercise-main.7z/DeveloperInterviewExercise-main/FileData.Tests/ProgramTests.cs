namespace FileData.Tests
{
    using FileData;
    using System;
    using NUnit.Framework;
     

    [TestFixture]
    public static class ProgramTests
    {

        /*----Task 1---------------------------------------------------------------------------------------------*/

        [TestCase(new object[] { "-v", "C:/test.txt" })]
        public static void CanCallTask1(string[] args)
        {
            string versionOutPut = Program.Task1(args);
            Assert.That(versionOutPut, Is.Not.Null);
        }

        [TestCase(null)]
        [TestCase("")]
        [TestCase("  ")]
        public static void CannotCallTask1WithNullArgs(string[] args)
        {
            Assert.Throws<ArgumentNullException>(() => Program.Task1(args));
        }
        /*-------------------------------------------------------------------------------------------------------*/

        /*----Task 2---------------------------------------------------------------------------------------------*/
        [Test]
        [TestCase(new object[] { "-v", "C:/test.txt" })]
        [TestCase(new object[] { "--v", "C:/test.txt" })]
        [TestCase(new object[] { "/v", "C:/test.txt" })]
        [TestCase(new object[] { "--version", "C:/test.txt" })]
        [TestCase(new object[] { "-s", "C:/test.txt" })]
        [TestCase(new object[] { "--s", "C:/test.txt" })]
        [TestCase(new object[] { "/s", "C:/test.txt" })]
        [TestCase(new object[] { "--size", "C:/test.txt" }, TestName = "Test 1")]
        public static void CanCallTask2_v0(string[] args)
        {
            object outPut = Program.Task2(args);
            Assert.That(outPut, Is.Not.Null);
        }  

        [TestCase(null)]
        [TestCase("")]
        [TestCase("  ")]
        public static void CannotCallTask2WithNullArgs(string[] args)
        {
            Assert.Throws<ArgumentNullException>(() => Program.Task2(args));
        }
        /*-------------------------------------------------------------------------------------------------------*/
    }
}