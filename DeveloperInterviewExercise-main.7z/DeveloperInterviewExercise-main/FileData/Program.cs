﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {       
        public static readonly string[] versionArray = { "-v", "--v", "/ v", "--version" };
        public static readonly string[] sizeArray = { "-s", "--s", "/ s", "--size" };
        static readonly FileDetails fileDetails = new FileDetails();
        public static void Main(string[] args)
        {
            Task1(args); //Task 1
            Task2(args); // Task 2

            Console.ReadLine();
        }

        /// <summary>
        /// * If the first argument is `-v`, pass the second argument to `FileDetails.Version`
        /// * Write the response from `FileDetails.Version` to the Console
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static string Task1(string[] args)
        {
            string _version = string.Empty;
            try
            {
                /*----Task 1---------------------------------------------------------------------------------------------*/
                if (args.Count() > 1)
                {
                    if (args[0] == "-v")
                    {
                        _version = fileDetails.Version(args[1]);
                        Console.WriteLine("OutPut of Task1 - " + _version);
                    }
                }
                else throw new ArgumentNullException();
            }
            catch (Exception ex) { Console.WriteLine("Error occured in Task1 -  ", ex.ToString()); }
            return _version;
        }

        /// <summary> 
        ///* To call `FileDetails.Version` if the first argument is either of `-v`, `--v`, `/v`, `--version`
        ///* To call `FileDetails.Size` if the first argument is either of `-s`, `--s`, `	`, `--size`
        /// </summary>
        /// <param name="args"></param>
        public static object Task2(string[] args)
        {
            object _outPutString = string.Empty;
            try
            {
                /*----Task 2---------------------------------------------------------------------------------------------*/  
                if (args.Count() > 1)
                {
                    if (versionArray.Contains(args[0]))                    
                        _outPutString = fileDetails.Version(args[1]);                    
                    else if (sizeArray.Contains(args[0]))
                        _outPutString = fileDetails.Size(args[1]);                
                }
                else throw new ArgumentNullException();
            }
            catch (Exception ex) { Console.WriteLine("Error occured in Task2 -  ", ex.ToString()); }
            return _outPutString;
        }
    }
}
